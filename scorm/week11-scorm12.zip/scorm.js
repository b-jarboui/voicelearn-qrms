/* SCORM 1.2 bridge: resume position, completion and quiz score. Runs without an LMS too. */
window.VLSCORM=(function(){
  var KEY='vl-qrms-w11-scene-v2', api=null, t0=Date.now(), last={}, done=false;
  function find(w){ var n=0; while(w&&!w.API&&w.parent&&w.parent!==w&&n++<10) w=w.parent; return w&&w.API||null; }
  try{ api=find(window)||(window.opener&&find(window.opener)); }catch(e){}
  function get(k){ try{ return api?String(api.LMSGetValue(k)||''):'' }catch(e){ return '' } }
  function set(k,v){ v=String(v); if(!api||last[k]===v) return; last[k]=v; try{ api.LMSSetValue(k,v) }catch(e){} }
  function save(){ try{ api&&api.LMSCommit('') }catch(e){} }
  if(api){
    try{ api.LMSInitialize('') }catch(e){}
    var st=get('cmi.core.lesson_status'); if(!st||st==='not attempted') set('cmi.core.lesson_status','incomplete');
    var loc=parseInt(get('cmi.core.lesson_location'),10);
    try{ if(loc>0) localStorage.setItem(KEY,String(loc)) }catch(e){}
    save();
  }
  function hms(s){ function p(n){return (n<10?'0':'')+n} return p(Math.floor(s/3600))+':'+p(Math.floor(s/60)%60)+':'+p(Math.floor(s%60)); }
  function sync(){
    if(!api) return;
    try{
      var s=window.VLSTATE&&VLSTATE(); if(!s) return;
      set('cmi.core.lesson_location', s.si);
      var q=(typeof s.quiz==='number'&&s.qn)?s.quiz:null;
      if(q!==null){ set('cmi.core.score.min',0); set('cmi.core.score.max',100); set('cmi.core.score.raw',Math.round(q/s.qn*100)); }
      if(s.si===s.n-1||s.seen>=Math.ceil(s.n*0.8)||q!==null){ set('cmi.core.lesson_status','completed'); }
      save();
    }catch(e){}
  }
  function finish(){
    if(!api||done) return; done=true; sync();
    set('cmi.core.exit','suspend'); set('cmi.core.session_time',hms((Date.now()-t0)/1000));
    try{ api.LMSCommit(''); api.LMSFinish('') }catch(e){}
  }
  return { api:function(){return api}, track:function(){ if(!api) return; setInterval(sync,5000); addEventListener('pagehide',finish); addEventListener('beforeunload',finish); } };
})();
